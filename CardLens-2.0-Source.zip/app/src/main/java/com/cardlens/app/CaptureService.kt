package com.cardlens.app

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView\nimport android.widget.LinearLayout\nimport android.graphics.drawable.GradientDrawable
import java.io.File
import java.io.FileOutputStream

class CaptureService : Service() {
    companion object { const val SHOW = "show"; const val CAPTURE = "capture"; private const val CHANNEL = "cardlens" }
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: View? = null\n    private var menu: View? = null
    private var selector: SelectionView? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: android.hardware.display.VirtualDisplay? = null
    override fun onBind(intent: Intent?) = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager; val channel = NotificationChannel(CHANNEL, "CardLens capture", NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(channel) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            SHOW -> showBubble()
            CAPTURE -> {
                val notification = Notification.Builder(this, CHANNEL).setContentTitle("CardLens").setContentText("Capturing selected card").setSmallIcon(android.R.drawable.ic_menu_camera).build()
                startForeground(1, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
                @Suppress("DEPRECATION") val resultData = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("resultData", Intent::class.java) else intent.getParcelableExtra<Intent>("resultData")
                if (resultData != null) capture(intent.getIntExtra("resultCode", Activity.RESULT_CANCELED), resultData) else showBubble()
            }
            else -> showBubble()
        }
        return START_NOT_STICKY
    }
    private fun showBubble() {
        if (bubble != null) { bubble?.visibility = View.VISIBLE; return }
        val v = TextView(this).apply {
            text = "⌕"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            elevation = 9.dp().toFloat()
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(58, 111, 180), Color.rgb(32, 47, 89))).apply {
                cornerRadius = 30.dp().toFloat()
                setStroke(2.dp(), Color.rgb(151, 204, 250))
            }
        }
        val p = WindowManager.LayoutParams(54.dp(), 54.dp(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.START
                x = resources.displayMetrics.widthPixels - 70.dp()
                y = 180.dp()
            }
        var downX = 0f
        var downY = 0f
        var initialX = 0
        var initialY = 0
        var moved = false
        v.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    initialX = p.x; initialY = p.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (kotlin.math.abs(event.rawX-downX) > 10 || kotlin.math.abs(event.rawY-downY) > 10) moved = true
                    if (moved) {
                        p.x = (initialX + event.rawX-downX).toInt().coerceIn(0, resources.displayMetrics.widthPixels-54.dp())
                        p.y = (initialY + event.rawY-downY).toInt().coerceIn(0, resources.displayMetrics.heightPixels-54.dp())
                        wm.updateViewLayout(v,p)
                        hideMenu()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggleMenu(p); true }
                else -> true
            }
        }
        wm.addView(v,p)
        bubble = v
    }
    private fun toggleMenu(bubbleParams: WindowManager.LayoutParams) {
        if (menu != null) { hideMenu(); return }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8.dp(), 8.dp(), 8.dp(), 8.dp())
            elevation = 12.dp().toFloat()
            background = GradientDrawable().apply {
                setColor(Color.rgb(31, 40, 59))
                cornerRadius = 16.dp().toFloat()
                setStroke(1.dp(), Color.rgb(90, 119, 159))
            }
        }
        fun addOption(label: String, action: () -> Unit) {
            layout.addView(TextView(this).apply {
                text = label
                textSize = 17f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(16.dp(), 10.dp(), 12.dp(), 10.dp())
                setOnClickListener { hideMenu(); action() }
            })
        }
        addOption("⌕   Scan") {
            bubble?.visibility = View.GONE
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("capture", true))
        }
        addOption("×   Close app") { stopSelf() }
        val p = WindowManager.LayoutParams(164.dp(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.START
                x = (bubbleParams.x - 110.dp()).coerceIn(0, resources.displayMetrics.widthPixels - 164.dp())
                y = (bubbleParams.y + 58.dp()).coerceAtMost(resources.displayMetrics.heightPixels - 120.dp())
            }
        wm.addView(layout,p)
        menu = layout
    }
    private fun hideMenu() { menu?.let { wm.removeView(it) }; menu = null }
    private fun capture(code: Int, data: Intent) {
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { cleanupCapture() } }, handler)
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels; val height = metrics.heightPixels
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            display = projection!!.createVirtualDisplay("CardLens", width, height, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
            handler.postDelayed({
                val image = reader?.acquireLatestImage()
                if (image == null) { cleanupCapture(); showBubble(); return@postDelayed }
                try {
                    val plane = image.planes[0]; val stride = plane.pixelStride; val rowStride = plane.rowStride
                    val padded = Bitmap.createBitmap(width + (rowStride - stride * width) / stride, height, Bitmap.Config.ARGB_8888)
                    padded.copyPixelsFromBuffer(plane.buffer)
                    val bitmap = Bitmap.createBitmap(padded, 0, 0, width, height)
                    padded.recycle(); cleanupCapture(); showSelection(bitmap)
                } catch (_: Exception) { cleanupCapture(); showBubble() } finally { image.close() }
            }, 450)
        } catch (_: Exception) { cleanupCapture(); showBubble() }
    }
    private fun showSelection(bitmap: Bitmap) {
        val view = SelectionView(this, bitmap, { rect ->
            removeSelector()
            try {
                val crop = Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height())
                val folder = File(cacheDir, "shared").apply { mkdirs() }
                val file = File(folder, "card-${System.currentTimeMillis()}.png")
                FileOutputStream(file).use { crop.compress(Bitmap.CompressFormat.PNG, 100, it) }
                crop.recycle()
                startActivity(Intent(this, ShareActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("path", file.absolutePath))
            } catch (_: Exception) { showBubble() } finally { bitmap.recycle() }
        }, { removeSelector(); bitmap.recycle(); showBubble() })
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_FULLSCREEN, PixelFormat.TRANSLUCENT)
        wm.addView(view, p); selector = view
    }
    private fun removeSelector() { selector?.let { wm.removeView(it) }; selector = null }
    private fun cleanupCapture() { display?.release(); display = null; reader?.close(); reader = null; projection?.let { projection = null; it.stop() }; stopForeground(STOP_FOREGROUND_REMOVE) }
    private fun Int.dp() = (this * resources.displayMetrics.density).toInt()
    override fun onDestroy() { hideMenu(); removeSelector(); bubble?.let { wm.removeView(it) }; bubble = null; cleanupCapture(); super.onDestroy() }
}

private class SelectionView(context: Context, private val screenshot: Bitmap, private val onCrop: (Rect) -> Unit, private val onCancel: () -> Unit) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var startX = 0f; private var startY = 0f; private var endX = 0f; private var endY = 0f; private var dragging = false
    override fun onDraw(canvas: Canvas) {
        canvas.drawBitmap(screenshot, null, Rect(0, 0, width, height), paint)
        paint.color = 0x55000000; canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        if (dragging) {
            val r = RectF(minOf(startX,endX), minOf(startY,endY), maxOf(startX,endX), maxOf(startY,endY))
            paint.color = Color.WHITE; paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; canvas.drawRect(r, paint); paint.style = Paint.Style.FILL
            paint.color = 0x44FFFFFF; canvas.drawRect(r, paint)
        } else { paint.color = Color.WHITE; paint.textSize = 44f; canvas.drawText("Drag around card • tap to cancel", 25f, 75f, paint) }
        paint.color = Color.WHITE; paint.style = Paint.Style.FILL
    }
    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { startX = event.x; startY = event.y; endX = startX; endY = startY; dragging = true; invalidate(); return true }
            MotionEvent.ACTION_MOVE -> { endX = event.x; endY = event.y; invalidate(); return true }
            MotionEvent.ACTION_UP -> {
                endX = event.x; endY = event.y
                if (kotlin.math.abs(endX-startX) < 15 || kotlin.math.abs(endY-startY) < 15) { onCancel(); return true }
                val sx = screenshot.width.toFloat()/width; val sy = screenshot.height.toFloat()/height
                val l = (minOf(startX,endX)*sx).toInt().coerceIn(0,screenshot.width-1)
                val t = (minOf(startY,endY)*sy).toInt().coerceIn(0,screenshot.height-1)
                val r = (maxOf(startX,endX)*sx).toInt().coerceIn(l+1,screenshot.width)
                val b = (maxOf(startY,endY)*sy).toInt().coerceIn(t+1,screenshot.height)
                onCrop(Rect(l,t,r,b)); return true
            }
        }
        return true
    }
}
