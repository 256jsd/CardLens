package com.cardlens.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings

class MainActivity : Activity() {
    private val captureRequest = 42
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent.getBooleanExtra("capture", false)) requestCapture() else startBubble()
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("capture", false)) requestCapture() else startBubble()
    }
    override fun onResume() {
        super.onResume()
        if (!intent.getBooleanExtra("capture", false) && Settings.canDrawOverlays(this)) {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.SHOW))
            finish()
        }
    }
    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.SHOW))
            finish()
        }
    }
    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) { finish(); return }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }
    @Deprecated("Android projection permission callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).setAction(CaptureService.CAPTURE)
                .putExtra("resultCode", resultCode).putExtra("resultData", data))
        } else {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.SHOW))
        }
        finish()
    }
}
