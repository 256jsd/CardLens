# CardLens — minimal Android screen-crop sharing app

## Build
Open this folder in Android Studio (JDK 17, Android SDK 35). Let Gradle sync, then choose **Build > Build APK(s)**. Install `app/build/outputs/apk/debug/app-debug.apk` on your Android phone.

## Use
1. Install Google Lens or the Google app (sharing target availability depends on installed apps).
2. Open CardLens, tap **Enable floating button**, and grant **Display over other apps** permission. Return to CardLens and tap enable again.
3. In an eBay video, tap the blue floating circle. Approve Android's screen-capture dialog (prefer **Entire screen** when offered).
4. Drag a rectangle around the card in the frozen screenshot.
5. Choose Google Lens, if offered, from Android's share sheet. Add `price` in Lens manually if desired.
6. To remove the bubble, open CardLens and tap **Disable floating button**.

## Notes / limitations
- Android requires capture consent per search. On Android 14+, a projection token is single-use.
- This app shares an image; it does **not** programmatically trigger a Google Lens search or append `price` to Lens queries.
- Some apps protect video frames against capture; these may appear black.
- Screen selection is a full-screen overlay; accessibility, device cutouts, multiwindow, orientation, and OEM-specific behavior may require testing.
- The floating button is hidden during capture, and the service does not record continuously.
- Source code is provided; this project has not been compiled or tested on a physical device in this environment.
