package com.cardlens.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequest = 42
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome(); if (intent.getBooleanExtra("capture", false)) requestCapture() }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); if (intent.getBooleanExtra("capture", false)) requestCapture() }
    private fun showHome() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 70, 48, 32) }
        layout.addView(TextView(this).apply { text = "CardLens\n\nEnable the floating button, then return to an eBay video. Tap the button to select a card and share the crop to Google Lens.\n\nScreen capture approval is required for each search."; textSize = 18f })
        layout.addView(Button(this).apply { text = "Enable floating button"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else startService(Intent(this@MainActivity, CaptureService::class.java).setAction(CaptureService.SHOW)) } })
        layout.addView(Button(this).apply { text = "Disable floating button"; setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)) } })
        setContentView(layout)
    }
    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) { showHome(); return }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }
    @Deprecated("Android projection permission callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).setAction(CaptureService.CAPTURE).putExtra("resultCode", resultCode).putExtra("resultData", data))
        }
        finish()
    }
}
